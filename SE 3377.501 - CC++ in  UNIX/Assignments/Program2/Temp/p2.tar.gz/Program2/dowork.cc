#include "program2.h"

using namespace std;
void DoWork(){

  std:: cout << "In do work";

  return;
}
