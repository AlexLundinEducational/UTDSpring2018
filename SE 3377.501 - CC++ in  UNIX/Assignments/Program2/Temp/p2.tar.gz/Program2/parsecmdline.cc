
#include "program2.h"
using namespace std;
void parseCmdLine (int argc, char * argv []){

  cout << "In parseCmdLine";


 

    

    try {  

      // Define the command line object, and insert a message
      // that describes the program. The "Command description message" 
      // is printed last in the help text. The second argument is the 
      // delimiter (usually space) and the last one is the version number. 
      // The CmdLine object parses the argv array based on the Arg objects
      // that it contains. 
      TCLAP::CmdLine cmd("Displays useage information and exits", ' ', "0.0");

      // Define a value argument and add it to the command line.
      // A value arg defines a flag and a type of value that it expects,
      // such as "-n Bishop".
       TCLAP::ValueArg<std::string> outputFileArg("o","outfile","<output file name>",true,"homer","string");

      // Add the argument outputFileArg to the CmdLine object. The CmdLine object
      // uses this Arg to parse the command line.
      cmd.add( outputFileArg );

      // Define a switch and add it to the command line.
      TCLAP::SwitchArg upperSwitch("r","upper","Convert all text to uppercase", cmd, false);
      
      // Define a switch and add it to the command line.
      TCLAP::SwitchArg lowerSwitch("l","upper","Convert all text to lowercase", cmd, false);
      
      TCLAP::UnlabeledValueArg<string>  inputFileNoLabel( "inputfile", "<input file name>", true ,"string" ,
							  "Input File", false );
      cmd.add( inputFileNoLabel );
      
      // Parse the argv array.
      cmd.parse( argc, argv );
      // Get the value parsed by each arg. 
      std::string inputFilePath = inputFileNoLabel.getValue();
      std::string outputFilePath = outputFileArg.getValue();
      bool upperCaseInput = upperSwitch.getValue();
      bool lowerCaseInput = lowerSwitch.getValue();
      
      
      
      // Do what you intend. 
      if ( upperCaseInput )
	{
	  std::cout << "Input (uppercase) is: " << std::endl;
	}
      
      // Do what you intend. 
      if ( lowerCaseInput )
	{
	  std::cout << "Lowercase " << std::endl;
	}
      
      } 
      catch (TCLAP::ArgException &e)  // catch any exceptions
	{ std::cerr << "error: " << e.error() << " for arg " << e.argId() << std::endl; }






  
  return;
}
