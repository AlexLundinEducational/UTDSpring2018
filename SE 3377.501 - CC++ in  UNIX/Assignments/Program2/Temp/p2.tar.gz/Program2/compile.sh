#!/bin/bash
echo compiling
g++ -I ~/Program2/include/ -c ~/Program2/program2.cc
g++ -I ~/Program2/include -c  ~/Program2/parsecmdline.cc
g++ -I ~/Program2/include -c ~/Program2/dowork.cc
echo compile complete
echo Linking files to create executable
g++  program2.o parsecmdline.o dowork.o -o hw2
echo Link Complete
echo Done 
exit 0

