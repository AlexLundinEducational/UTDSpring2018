#include "program2.h"

using namespace std;
int main(int argc, char * argv[]);
int main (int argc, char * argv[]){
  cout << "main"  << endl;
	return(0);
}
