#Alex Lundin
#AML140830@utdallas.edu
#SE 3377.501 - CC++ in  UNIX
#!/bin/bash
rm stdout.log
rm stderr.log
echo Running 'hw2' with 0 arguments:
echo stdout appended to stdout.log
echo stderr appended to stderr.log
./hw2
exit 0
