//Alex Lundin
//Exam 1
//AML140830@utdallas.edu
//SE 3357.501 - C++ in UNIX
#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string>
using namespace std;
int main(int argc, char *argv[]);
int main(int argc, char *argv[]){
  FILE *stream;
  cout << "argc was:" << argc << endl;
  freopen( "stderr.log", "a", stderr );
  std::cerr << "argc was:" << argc << endl;
  // stream = freopen ("CON" , "a", stderr);

  // print loop for array
  for (int a = 0; a < argc; a = a + 1){
    cout << (argv[a]) << endl;
    std::cerr << (argv[a]) << endl;
    // stream = freopen ("CON" , "a", stderr);
  }
  cout << "Program Exam1.cc done!" << endl;

  std::cerr << "Program Exam1.cc done!" << endl;
  stream = freopen("CON", "a", stderr);
  return 0;
}
