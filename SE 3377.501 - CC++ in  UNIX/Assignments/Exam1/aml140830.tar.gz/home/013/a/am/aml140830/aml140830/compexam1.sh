#Alex Lundin
#Exam 1
#AML140830@utdallas.edu
#SE 3357.501 - C++ in UNIX
#!/bin/bash
echo Setting TEMPDIR environment variable to /scratch
echo Compiling exam1.cc
g++ -c exam1.cc
echo Linking file to create executable exam1
g++ exam1.o -o exam1
echo Done
exit 0
