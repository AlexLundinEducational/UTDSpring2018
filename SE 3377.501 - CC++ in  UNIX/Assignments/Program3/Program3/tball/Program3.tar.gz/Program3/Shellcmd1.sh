#Alex Lundin
#AML140830@utdallas.edu
#SE 3377.501 - CC++ in  UNIX
#accept full filepath of gawk location as first and only argument
#!/bin/bash
gawkLocation=$1
$1 --version